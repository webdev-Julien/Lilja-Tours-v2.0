### Geysir and Strokkur

Geysir gave its name to all the geysers in the world. This is where the word "Geyser" originates from. Geysir comes from the Icelandic "Að geysa" which means: To gush.

But Geysir is nowadays dormant. It came out of the ground for the last time in the year 2000. Its little brotherStrokkur, is still very active, and erupting every 5 to 10 minutes on average.
