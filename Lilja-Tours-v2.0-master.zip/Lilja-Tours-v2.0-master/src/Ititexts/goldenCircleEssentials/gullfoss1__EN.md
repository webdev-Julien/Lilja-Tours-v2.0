### Gullfoss

The touristic route that we call "Golden Circle" is named after this waterfall. Its name, Gullfoss, means "Golden waterfall".

There are different stories and legends to explain the name of Gullfoss. We will not write them here, and will leave to your guide the pleasure of telling you about them! Also note that this waterfall almost disappeared due to an industrial project, consisting in harnessing the power of the river in a hydropower plant.
