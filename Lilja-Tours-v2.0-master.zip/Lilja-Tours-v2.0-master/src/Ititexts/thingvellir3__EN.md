### Þingvellir National Park

Start your **Golden Circle adventure** at **Þingvellir National Park**, where nature and history collide.

Established in 930, it’s home to the **world’s first parliament**, where settlers met to govern Iceland. The site remained in use until 1798 and earned **UNESCO World Heritage** status in 2004.

Þingvellir is also the only place where the **Mid-Atlantic Ridge rises above sea level**, separating the Eurasian and North American plates. At the Hákið viewing platform, you’ll stand at the edge of the American continent.

Continue with a short walk to **Öxarárfoss**, a scenic waterfall steeped in history.

